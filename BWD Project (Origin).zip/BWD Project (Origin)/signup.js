document.addEventListener("DOMContentLoaded", function() {
    loginForm.addEventListener("submit", function(event) {
        window.location.href = "login.html";
        alert('Sign up successful.');
    });
});


